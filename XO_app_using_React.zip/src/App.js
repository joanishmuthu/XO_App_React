import { useState } from "react";
import "./App.css";
import SelectTile from "./Components/SelectTile";
import { TicTac } from "./Components/TicTac";

function App() {
  let [board,setboard]=useState([["","",""],["","",""],["","",""]])
  let [x_val,setx]=useState(true);
  function CheckWinningStraight(i,j,board,count,val){
      if(i===board.length){
      return count;
    }
    else{
      if(board[i][j]===val){
        count++;
      }
      return CheckWinningStraight(i+1,j,board,count,val)
    }
  }
  function CheckWinningHorizondal(i,j,board,count,val){
    if(j===board[0].length){
      return count;
    }
    else{
      if(board[i][j]===val){
        count++;
      }
      return CheckWinningHorizondal(i,j+1,board,count,val)
    }
  }
  function CheckWinningDiagonal(i,j,board,count,val){
    if(j===board[0].length || i===board.length){
      return count;
    }
    else{
      if(board[i][j]===val){
        count++;
      }
      
      return CheckWinningDiagonal(i+1,j+1,board,count,val)
    }
  }
  const boardChecker = () => {
    for (let i = 0; i < board.length; i++) {
      for (let j = 0; j < board[0].length; j++) {
        console.log(board[i][j]);
        if(board[i][j]===''){
          break;
        }
        let a = CheckWinningStraight(i, j, board, 0, board[i][j]);
        let b = CheckWinningHorizondal(i, j, board, 0, board[i][j]);
        let c = CheckWinningDiagonal(i, j, board, 0, board[i][j]);
        console.log("value of a b and c is" + a + " " + b + " " + c);
        if (a === 3 || b === 3 || c === 3) {
          alert(board[i][j] + " is the winner");
          setboard([['','',''],['','',''],['','','']])
        }
      }
    }
  };
  
  const setXorY = ( x, y) => {
    if (board[x][y] === '') {
      const newBoard = [...board];
      if(x_val){
        newBoard[x][y]='X';
      }
      else{
        newBoard[x][y]='Y';
      }
      setx(!x_val)
      setboard(newBoard);
    }
    else{
      alert("Enter a different x and y value")
    }
  };
  const valuefinder=()=>{
    if(x_val){
      return "X"
    }
    else{
      return "Y"
    }
  }
  return <div>
    <TicTac board={board}></TicTac>
    <h3>Enter {valuefinder()}</h3>
    <SelectTile setBoard={setXorY} check={boardChecker}></SelectTile>
  </div>;
  
}

export default App;
