let board=[["X","",""],["X","",""],["X","",""]]
function CheckWinningStraight(i,j,board,count,val){
    if(i===board.length){
    return count;
  }
  else{
    if(board[i][j]===val){
      count++;
    }
    return CheckWinningStraight(i+1,j,board,count,val)
  }
}
function CheckWinningHorizondal(i,j,board,count,val){
  if(j===board[0].length){
    return count;
  }
  else{
    if(board[i][j]===val){
      count++;
    }
    return CheckWinningHorizondal(i,j+1,board,count,val)
  }
}
function CheckWinningDiagonal(i,j,board,count,val){
  if(j===board[0].length || i===board.length){
    return count;
  }
  else{
    if(board[i][j]===val){
      count++;
    }
    
    return CheckWinningDiagonal(i+1,j+1,board,count,val)
  }
}
const boardChecker = () => {
  for (let i = 0; i < board.length; i++) {
    for (let j = 0; j < board[0].length; j++) {
      console.log(board[i][j]);
      let a = CheckWinningStraight(i, j, board, 0, board[i][j]);
      let b = CheckWinningHorizondal(i, j, board, 0, board[i][j]);
      let c = CheckWinningDiagonal(i, j, board, 0, board[i][j]);
      console.log("value of a b and c is" + a + " " + b + " " + c);
      if (a === 3 || b === 3 || c === 3) {
        alert(board[i][j] + " is the winner");
      }
    }
  }
};
boardChecker()