import React, { useState } from 'react'

export const NewGoal = (props) => {
  let [text,settext]=useState("")
  const setHandler=()=>{
    props.set(text)
    settext("")
  }
  const changeHandler=(e)=>{
    settext(e.target.value)
  }
  return (
    <div>
      <input type='text' placeholder='Enter your new goal' onChange={changeHandler} value={text}></input>
      <button type='button' onClick={setHandler}>Add Goals!</button>
    </div>
  )
}
