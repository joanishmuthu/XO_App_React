import React, { useState } from 'react'

export const Counter = () => {
  let [count,Setcount]=useState(0);
  function increment(){
    Setcount((prev)=>{
        return prev+1
    })
  }
  function decrement(){
    Setcount(
        (prev)=>{
            return prev-1;
        }
    )
  }
  return (
    <div>
        <h1>Counter</h1>
        <h3>{count}</h3>
        <button type='button' onClick={increment}>Increment</button>
        <button type='button' onClick={decrement}>Decrement</button>
    </div>
  )
}
