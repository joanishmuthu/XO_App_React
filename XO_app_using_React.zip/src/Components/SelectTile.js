import React, { useState } from 'react'

const SelectTile = (props) => {
  let [x,setx]=useState();
  let [y,sety]=useState()
  const XHandler=(e)=>{
    setx(e.target.value)
  }
  const YHandler=(e)=>{
    sety(e.target.value)
  }
  const SubmitHandler = () => {
    props.setBoard(x, y);
    props.check()
  };
  
  return (
    <div>
        <input placeholder='Enter x coordinate' onChange={XHandler} value={x}></input>
        <input placeholder='Enter y coordinate' onChange={YHandler} value={y}></input>
        <button type='button' onClick={SubmitHandler}>Submit</button>
    </div>
  )
}

export default SelectTile