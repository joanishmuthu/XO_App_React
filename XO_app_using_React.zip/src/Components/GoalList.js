import React from "react";

const GoalList = (props) => {
  return (
    <div>
      <ul>
        {props.goals.map((item) => {
          return <li>{item}</li>;
        })}
      </ul>
    </div>
  );
};

export default GoalList;
