import React from "react";
import "./TicTac.css";

export const TicTac = (props) => {
  let board = props.board;

  return (
    <div>
      <table title="Tic Tac Toe" className="title">
        <tbody>
          {board.map((row, rowIndex) => (
            <tr key={rowIndex}>
              {row.map((cell, colIndex) => (
                <td key={colIndex}>{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
